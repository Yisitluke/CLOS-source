import json
import subprocess
import time
from getpass import getpass
import hashlib
import os
import sys

def exFallback():
    print("error: an important kernel python file was not found. the system cannot work. please fix the issue.")
    while True:
        time.sleep(5)

try:
    import OprBoot


    if __name__ == "__main__":
        os.chdir(os.path.dirname(os.path.abspath(__file__)))
        OprBoot.BootMenu()
except ModuleNotFoundError:
    exFallback()
