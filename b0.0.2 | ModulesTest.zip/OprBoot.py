import json
import subprocess
import time
from getpass import getpass
import hashlib
import os
import sys

def exFallback():
        print("error: an important kernel python file was not found. the system cannot work. please fix the issue.")
        while True:
            time.sleep(5)

try:
    import Opr
    import OprSys as OprInit

    class BootMenu:
        def __init__(self):
            Opr.PathEnsure()
            time.sleep(2.5)
            self.bMenu()

        def SelectUser(self):
            print("BootLoader | Boot")
            Opr.DisplayUser()
            print("")
            direct = input("")
            Opr.clear()
            (a, usrdat, usrpat) = Opr.IdentifyUser(direct)
            if a:
                OprInit.OprSys(usrdat, usrpat)
            else:
                print(Opr.rReturn(2, "BootLoader:UserNotFound", warnN=False, x1=direct))
                time.sleep(2)
                Opr.clear()

        def CreateUser(self):
            print("Username\n")
            username = input("")
            Opr.clear()
            if not username.isalpha() or len(username) > 15:
                print(rReturn(2, "BootLoader:InvalidUsernameInput", warnN=False, x1=username))
                time.sleep(2)
                Opr.clear()
            else:
                username = username.lower()
                print("Password\n")
                passwd = getpass("")
                Opr.DefineUserFile(Opr.DefineUserData(username, passwd))
                Opr.clear()

        def bMenu(self):
            while True:
                print("BootLoader | Main Menu")
                print("0: Shutdown")
                print("1: Boot")
                print("2: Create User Account\n")
                opt = input("")
                if opt == "0":
                    Opr.SystemShutdown(False, 0)
                elif opt == "1":
                    Opr.clear()
                    self.SelectUser()
                elif opt == "2":
                    Opr.clear()
                    self.CreateUser()
                else:
                    Opr.clear()
                    print(Opr.rReturn(2, ".:InvalidInput", warnN=False))
                    time.sleep(2)
                    Opr.clear()
except ModuleNotFoundError:
    subprocess.run(("cls" if os.name == "nt" else "clear"), shell=True)
    exFallback()
