import json
import subprocess
import time
from getpass import getpass
import hashlib
import os
import sys

def exFallback():
    print("error: an important kernel python file was not found. the system cannot work. please fix the issue.")
    while True:
        time.sleep(5)

try:
    import Opr

    class OprSys:
        def __init__(self, usrdat, usrpat):
            self.UserData = usrdat
            self.UserPath = usrpat
            v = Opr.vobSyntax("DEVNULL")
            b = Opr.vobSyntax("b", Build="0.0.2", BuildX="ModulesTest")

            self.SystemInfo = {
            "-version-": (v if b is None else "[ > TESTING VERSION < ]"),
            "-build-": b
            }

            self.cmdR = {
            "clear": Opr.clear,
            "shutdown": lambda: Opr.WinixSystemShutdown(self.UserData, self.UserPath),
            "userinfo": lambda: Opr.WinixShowUserInfo(self.UserData),
            "sysinfo": lambda: Opr.WinixShowSystemInfo(self.SystemInfo),
            }

            self.Verify()

        def Verify(self):
            vcur = 0
            vtot = False
            while vcur < self.UserData["-settings-"]["-vmax-"]:
                print("Password Verification\n")
                inp = getpass("")
                Opr.clear()
                if Opr.CompareHash(inp, self.UserData["-password-"]):
                    print(Opr.rReturn(0, "OprSys:VerificationSuccess", warnN=False))
                    time.sleep(2)
                    vtot = True
                    Opr.clear()
                    break
                else:
                    vcur += 1
                    print(Opr.rReturn(1, "OprSys:VerificationSubFailure", warnN=False))
                    time.sleep(2)
                    Opr.clear()
            if vtot:
                self.System()
            else:
                Opr.clear()
                print(Opr.rReturn(2, "OprSys:VerificationFailure", warnN=False))
                time.sleep(2)
                Opr.clear()

        def WinixShell(self, command):
            tokens = command.split(";")
            commandBase = tokens[0]
            parameters = tokens[1:]
            execute = self.cmdR.get(commandBase)
            if execute:
                execute(*parameters)
            else:
                print(Opr.rReturn(2, "OprSys:UnknownCommand", warnN=False, x1=commandBase))

        def System(self):
            print("Command Line Operand | Winix\n")
            while True:
                command = input("WinixShell >  ")
                print("")
                self.WinixShell(command)
                print("")
except ModuleNotFoundError:
    subprocess.run(("cls" if os.name == "nt" else "clear"), shell=True)
    exFallback()
