import time

def exFallback(Port):
    print(f"error: an important kernel python file was not found. the system cannot work. please fix the issue.\n>>{Port}<<")
    while True:
        time.sleep(5)

try:
    import Opr
    import WinixShell as WS

    def get(usrdatPort, usrpatPort, sysdatPort):
        return {
        "clear": lambda: Opr.clear(),
        "shutdown": lambda: WS.WinixSystemShutdown(usrdatPort, usrpatPort),
        "userinfo": lambda: WS.WinixShowUserInfo(usrdatPort),
        "sysinfo": lambda: WS.WinixShowSystemInfo(sysdatPort),
        "crt": lambda fn, fi, fc: WS.WinixCreateFile(fn, fi, fc, usrdatPort["-username-"]),
        "del": lambda fn: WS.WinixDeleteFile(fn, usrdatPort["-username-"])
        }
except ModuleNotFoundError as e:
    exFallback(e)
