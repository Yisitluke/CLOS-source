import json
import subprocess
import shutil
import time
from getpass import getpass
import hashlib
import os
import sys





# ===  SYSTEM RESERVED  ===

def clear():
    subprocess.run(("cls" if os.name == "nt" else "clear"), shell=True)

def IdentifyJson(data):
    return json.dumps(data)

def IdentifyPython(data):
    return json.loads(data)

def IdentifyHash(data):
    return hashlib.sha256(data.encode()).hexdigest()

def CompareHash(given, target):
    if IdentifyHash(given) == target:
        return True
    else:
        return False

def DefineUserData(username, passwd):
    return {
    "-username-": username,
    "-password-": IdentifyHash(passwd),
    "-settings-": {
        "-vmax-": 3
        }
    }

def DefineUserFile(usrdat):
    if not os.path.exists(os.path.join("system", "users", f"{usrdat['-username-']}.json")):
        Save(usrdat, os.path.join("system", "users", f"{usrdat['-username-']}.json"))
    else:
        print(rReturn(2, "BootLoader:UserAlreadyExists", warnN=False))

def ValidateUserData(data):
    a = DefineUserData("username", "passwd")
    for i in a:
        if not i in data:
            return False
        if isinstance(a[i], dict):
            for aS in a[i]:
                if not aS in data[i]:
                    return False
    return True

def rReturn(level, restype, warnN, x1=None, x2=None):
    if level == -1:
        level = "OPRND;"
    if level == 0:
        level = "SUCCE;"
    if level == 1:
        level = "WARN;"
    if level == 2:
        level = "ERR;"

    if restype == "BootLoader:UserNotFound":
        restype = f"USER '{x1.lower()}' WAS NOT FOUND."
    if restype == "BootLoader:UserAlreadyExists":
        restype = "USER IS ALREADY TAKEN."
    if restype == "BootLoader:InvalidUsernameInput":
        restype = f"USERNAME '{x1}' IS NOT VALID."
    if restype == "OprSys:VerificationSuccess":
        restype = "VERIFICATION CORRECT."
    if restype == "OprSys:VerificationSubFailure":
        restype = "INCORRECT GIVEN PASSWORD."
    if restype == "OprSys:VerificationFailure":
        restype = "VERIFICATION INCORRECT."
    if restype == "OprSys:UnknownCommand":
        restype = f"'{x1}' IS UNKNOWN."
    if restype == "FileMng:FileAlreadyExists":
        restype = "FILE ALREADY EXISTS."
    if restype == "FileMng:FileNotFound":
        restype = f"FILE '{x1}' DOES NOT EXIST."
    if restype == "FileMng:PermissionDenied":
        restype = "YOU ARE NOT THE OWNER OF THIS FILE."
    if restype == ".:InvalidInput":
        restype = "INVALID INPUT."

    return f"{level} {restype}{(' CONTINUE THIS OPERATION?' if warnN else '')}"

def rYesNo():
    a = input("")
    if a.lower() == "y" or a.lower() == "yes":
        b = True
    elif a.lower() == "n" or a.lower() == "no":
        b = False
    else:
        return rReturn(2, ".:InvalidInput", warnN=False)
    return b, a

def Save(datPort, patPort):
    with open(patPort, "w") as f:
        f.write(IdentifyJson(datPort))

def Load(patPort):
    with open(patPort, "r") as f:
        dat = IdentifyPython(f.read())
    return dat

def IdentifyUser(target):
    a = (False, None, None)
    for i in list(os.scandir(os.path.join("system", "users"))):
        ref = Load(i.path)
        if not ValidateUserData(ref):
            continue
        try:
            if ref["-username-"] == target:
                a = (True, ref, i.path)
                break
        except KeyError:
            continue
    return a

def DisplayUser():
    for i in list(os.scandir(os.path.join("system", "users"))):
        ref = Load(i.path)
        if not ValidateUserData(ref):
            continue
        try:
            print(f"{ref['-username-']}")
        except KeyError:
            continue
        

def PathEnsure():
    if not os.path.exists("system"):
        os.mkdir("system")
    if not os.path.exists(os.path.join("system", "users")):
        os.mkdir(os.path.join("system", "users"))
    if not os.path.exists(os.path.join("system", "files")):
        os.mkdir(os.path.join("system", "files"))

def SystemShutdown(doesSave, exitstatus, usrdatPort=None, usrpatPort=None):
    if doesSave:
        Save(usrdatPort, usrpatPort)
    if os.path.exists("__pycache__"):
        shutil.rmtree("__pycache__")
    sys.exit(exitstatus)

def vobSyntax(VersionOrBuild, Version=None, Build=None, VersionX=None, BuildX=None):
    if VersionOrBuild == "v":
        struct = f"v{Version} | Version-{VersionX}"
    if VersionOrBuild == "b":
        struct = f"b{Build} | testingVersion-{BuildX}"
    return struct
