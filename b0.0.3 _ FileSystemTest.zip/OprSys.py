import json
import subprocess
import time
from getpass import getpass
import hashlib
import os
import sys

def exFallback(Port):
    print(f"error: an important kernel python file was not found. the system cannot work. please fix the issue.\n>>{Port}<<")
    while True:
        time.sleep(5)

try:
    import Opr
    import CommandDefine

    class OprSys:
        def __init__(self, usrdat, usrpat):
            self.UserData = usrdat
            self.UserPath = usrpat
            v = None
            b = Opr.vobSyntax("b", Build="0.0.3", BuildX="FileSystemTest")

            self.SystemInfo = {
            "-version-": (v if b is None else "[ > TESTING VERSION < ]"),
            "-build-": b
            }

            self.cmdR = CommandDefine.get(self.UserData, self.UserPath, self.SystemInfo)

            self.Verify()

        def Verify(self):
            vcur = 0
            vtot = False
            while vcur < self.UserData["-settings-"]["-vmax-"]:
                print("Password Verification\n")
                inp = getpass("")
                Opr.clear()
                if Opr.CompareHash(inp, self.UserData["-password-"]):
                    print(Opr.rReturn(0, "OprSys:VerificationSuccess", warnN=False))
                    time.sleep(2)
                    vtot = True
                    Opr.clear()
                    break
                else:
                    vcur += 1
                    print(Opr.rReturn(1, "OprSys:VerificationSubFailure", warnN=False))
                    time.sleep(2)
                    Opr.clear()
            if vtot:
                self.System()
            else:
                Opr.clear()
                print(Opr.rReturn(2, "OprSys:VerificationFailure", warnN=False))
                time.sleep(2)
                Opr.clear()

        def WinixShell(self, command):
            tokens = command.split(";")
            commandBase = tokens[0]
            parameters = tokens[1:]
            execute = self.cmdR.get(commandBase)
            if execute:
                execute(*parameters)
            else:
                print(Opr.rReturn(2, "OprSys:UnknownCommand", warnN=False, x1=commandBase))

        def System(self):
            print("Command Line Operand | Winix\n")
            while True:
                command = input("Winix >  ")
                print("")
                self.WinixShell(command)
                print("")
except ModuleNotFoundError as e:
    subprocess.run(("cls" if os.name == "nt" else "clear"), shell=True)
    exFallback(e)
