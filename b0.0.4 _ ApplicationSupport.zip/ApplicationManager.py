def exFallback(Port):
    print(f"error: an important kernel python file was not found. the system cannot work. please fix the issue.\n>>{Port}<<")
    while True:
        time.sleep(5)

try:
    import Opr

    class ApplicationManager:
        def __init__(self, app, usrdatPort, usrpatPort, sysdatPort):
            self.UserData = usrdatPort
            self.UserPath = usrpatPort
            self.SystemInfo = sysdatPort

            if app == "edix":
                self.EdixLauncher()

        def EdixLauncher(self):
            import EdixOper
            Opr.clear()
            EdixOper.Launch(self.UserData, self.UserPath, self.SystemInfo)
except ModuleNotFoundError as e:
    exFallback(e)
