import json
import subprocess
import time
from getpass import getpass
import hashlib
import os
import sys

def exFallback(Port):
    print(f"error: an important kernel python file was not found. the system cannot work. please fix the issue.\n>>{Port}<<")
    while True:
        time.sleep(5)

try:
    from Opr import clear
    import OprBoot


    if __name__ == "__main__":
        import STATICINFO
        dat = STATICINFO.get()
        time.sleep(1)
        print("""
             ▗▄▄▖▗▖    ▗▄▖  ▗▄▄▖
            ▐▌   ▐▌   ▐▌ ▐▌▐▌   
            ▐▌   ▐▌   ▐▌ ▐▌ ▝▀▚▖
            ▝▚▄▄▖▐▙▄▄▖▝▚▄▞▘▗▄▄▞▘                    
""")
        print("Command Line Operand System")
        if not dat["BUILD"] is None:
            print(f"{dat['BUILD']}")
        elif not dat["VERSION"] is None:
            print(f"{dat['VERSION']}")
        os.chdir(os.path.dirname(os.path.abspath(__file__)))
        time.sleep(2.5)
        clear()
        OprBoot.BootMenu()
except ModuleNotFoundError as e:
    exFallback(e)
