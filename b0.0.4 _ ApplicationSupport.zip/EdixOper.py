import time
import os

def exFallback(Port):
    print(f"error: an important kernel python file was not found. the system cannot work. please fix the issue.\n>>{Port}<<")
    while True:
        time.sleep(5)

try:
    import Opr

    class Launch:
        def __init__(self, usrdatPort, usrpatPort, sysdatPort):
            self.UserData = usrdatPort
            self.UserPath = usrpatPort
            self.SystemInfo = sysdatPort

            self.Run()

        def Run(self):
            while True:
                print("Edix | Main Menu")
                print("0: Exit")
                print("1: Edit File\n")
                opt = input("")
                if opt == "0":
                    Opr.clear()
                    break
                elif opt == "1":
                    Opr.clear()
                    self.SelectFile()
                else:
                    Opr.clear()
                    print(Opr.rReturn(".:InvalidInput", warnN=False))
                    time.sleep(2)
                    Opr.clear()

        def SelectFile(self):
            print("Edix | Select File")
            Opr.DisplayFile()
            print("")
            filename = input("")
            Opr.clear()
            if os.path.exists(os.path.join("system", "files", f"{filename}.json")):
                a = Opr.Load(os.path.join("system", "files", f"{filename}.json"))
                try:
                    if Opr.CompareHash(self.UserData["-username-"], a["-owner-"]):
                        self.EditFile(a)
                    else:
                        print(Opr.rReturn(2, "FileMng:PermissionDenied", warnN=False))
                        time.sleep(2)
                        Opr.clear()
                except KeyError:
                    print(Opr.rReturn(2, "FileMng:PermissionDenied", warnN=False))
            else:
                print(Opr.rReturn(2, "FileMng:FileNotFound", warnN=False, x1=filename))
                time.sleep(2)
                Opr.clear()

        def EditFile(self, file):
            print("Edix | Editing\n")
            lines = []
            while True:
                line = input("")
                if line == ":":
                    Opr.clear()
                    break
                lines.append(line)
            try:
                file["-content-"] = lines
                Opr.Save(file, os.path.join("system", "files", f"{file['-filename-']}.json"))
            except KeyError:
                pass
except ModuleNotFoundError as e:
    exFallback(e)
