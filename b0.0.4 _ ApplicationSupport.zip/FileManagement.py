import os
import time

def exFallback(Port):
    print(f"error: an important kernel python file was not found. the system cannot work. please fix the issue.\n>>{Port}<<")
    while True:
        time.sleep(5)

try:
    import Opr

    def DefineFileData(filename, filetype, usrnamePort):
        if filetype == "txt":
            filetype = "TextDocument"
        for i in filename:
            if not i.isalpha():
                filename = filename.replace(i, "-")
        filename = filename.lower()
        return {
        "-filename-": filename,
        "-filetype-": filetype,
        "-owner-": Opr.IdentifyHash(usrnamePort),
        "-content-": []
        }

    def DefineFileFile(filedat):
        if not os.path.exists(os.path.join("system", "files", f"{filedat['-filename-']}.json")):
            Opr.Save(filedat, os.path.join("system", "files", f"{filedat['-filename-']}.json"))
            print(Opr.rReturn(0, "FileMng:FileCreated", warnN=False, x1=filedat["-filename-"]))
        else:
            print(Opr.rReturn(2, "FileMng:FileAlreadyExists", warnN=False))

    def CatFileContent(filename):
        if os.path.exists(os.path.join("system", "files", f"{filename}.json")):
            a = Opr.Load(os.path.join("system", "files", f"{filename}.json"))
            try:
                for i in a["-content-"]:
                    print(f"{i}")
            except KeyError:
                print(Opr.rReturn(2, "FileMng:FileNotFound", warnN=False, x1=filename))
        else:
            print(Opr.rReturn(2, "FileMng:FileNotFound", warnN=False, x1=filename))

    def DeleteFile(filename, usrnamePort):
        a = False
        filename = filename.lower()
        for i in list(os.scandir(os.path.join("system", "files"))):
            b = Opr.Load(i.path)
            try:
                if Opr.CompareHash(usrnamePort, b["-owner-"]):
                    a = True
                    break
            except KeyError:
                continue
        if os.path.exists(os.path.join("system", "files", f"{filename}.json")):
            if a:
                os.remove(os.path.join("system", "files", f"{filename}.json"))
                print(Opr.rReturn(0, "FileMng:FileDeleted", warnN=False, x1=filename))
            else:
                print(Opr.rReturn(2, "FileMng:PermissionDenied", warnN=False))
        else:
            print(Opr.rReturn(2, "FileMng:FileNotFound", warnN=False, x1=filename))
except ModuleNotFoundError as e:
    exFallback(e)
