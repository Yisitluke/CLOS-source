def exFallback(Port):
    print(f"error: an important kernel python file was not found. the system cannot work. please fix the issue.\n>>{Port}<<")
    while True:
        time.sleep(5)

try:
    import Opr

    def get():
        return {
        "VERSION": None,
        "BUILD": Opr.vobSyntax("b", Build="0.0.4", BuildX="ApplicationSupport")
        }
except ModuleNotFoundError as e:
    exFallback(e)
