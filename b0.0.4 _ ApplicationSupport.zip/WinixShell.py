def exFallback(Port):
    print(f"error: an important kernel python file was not found. the system cannot work. please fix the issue.\n>>{Port}<<")
    while True:
        time.sleep(5)

try:
    import Opr
    import FileManagement as FileMng
    import ApplicationManager as AppMngr

    def ApplicationManagerRunner(app, usrdatPort, usrpatPort, sysdatPort):
        AppMngr.ApplicationManager(app, usrdatPort, usrpatPort, sysdatPort)

    def WinixSystemShutdown(usrdatPort, usrpatPort):
        Opr.SystemShutdown(True, 0, usrdatPort, usrpatPort)

    def WinixShowUserInfo(usrdatPort):
        print(f"Username: {usrdatPort['-username-']}")
        print(f"Settings:")
        print(f"    |Max Verification Attempts: {usrdatPort['-settings-']['-vmax-']}")

    def WinixShowSystemInfo(sysdatPort):
        print("Operating System Name (full): Command Line Operand System")
        print("Operating System Name (short): CLOS")
        print(f"Operating System Version: {sysdatPort['-version-']}")
        if not sysdatPort["-build-"] is None:
            print(f"Operating System Testing Version: {sysdatPort['-build-']}")
        print("Author and Creator: Lucas (Yisitluke on GitHub)")

    def WinixCreateFile(filename, filetype, usrnamePort):
        FileMng.DefineFileFile(FileMng.DefineFileData(filename, filetype, usrnamePort))

    def WinixCatFile(filename):
        FileMng.CatFileContent(filename)

    def WinixDeleteFile(filename, usrnamePort):
        FileMng.DeleteFile(filename, usrnamePort)
except ModuleNotFoundError:
    exFallback()
